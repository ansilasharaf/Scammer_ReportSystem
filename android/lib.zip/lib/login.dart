//
//
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:scammerreport/homepage.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// class LoginPage extends StatefulWidget {
//   const LoginPage({super.key});
//
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<LoginPage> {
//   final TextEditingController usernameController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//   bool isLoading = false;
//
//   Future<void> login() async {
//     final prefs = await SharedPreferences.getInstance();
//     String? url = prefs.getString("url");
//
//     if (url == null || url.isEmpty) {
//       Fluttertoast.showToast(msg: "Server URL not set.");
//       return;
//     }
//
//     String username = usernameController.text.trim();
//     String password = passwordController.text.trim();
//
//     if (username.isEmpty || password.isEmpty) {
//       Fluttertoast.showToast(msg: "Please enter username and password.");
//       return;
//     }
//
//     try {
//       setState(() => isLoading = true);
//
//       final response = await http.post(
//         Uri.parse("${url}staff_login"),
//         body: {
//           'username': username,
//           'password': password,
//         },
//       );
//
//       if (response.statusCode != 200) {
//         Fluttertoast.showToast(msg: "Server error: ${response.statusCode}");
//         setState(() => isLoading = false);
//         return;
//       }
//
//       final data = json.decode(response.body);
//
//       if (data['task'] == 'valid') {
//         String type = data['type']?.toString() ?? "";
//         String userId = data['lid']?.toString() ?? "";
//
//         // Save user info in SharedPreferences
//         await prefs.setString("type", type);
//         await prefs.setString("lid", userId);
//
//         // Navigate based on user type
//         if (type == 'Staff') {
//           Navigator.pushReplacement(
//             context,
//             MaterialPageRoute(builder: (context) => const UserHome()),
//           );
//         }
//
//         else {
//           Fluttertoast.showToast(msg: "Unknown user type.");
//         }
//       } else {
//         showDialog(
//           context: context,
//           builder: (_) => AlertDialog(
//             title: const Text("Login Failed"),
//             content: const Text("Invalid username or password."),
//             actions: [
//               TextButton(
//                 onPressed: () => Navigator.pop(context),
//                 child: const Text("OK"),
//               )
//             ],
//           ),
//         );
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: "Error: $e");
//     } finally {
//       setState(() => isLoading = false);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: const Text("Login")),
//       body: Center(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(24.0),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               TextField(
//                 controller: usernameController,
//                 decoration: const InputDecoration(
//                   labelText: "Username",
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 15),
//               TextField(
//                 controller: passwordController,
//                 obscureText: true,
//                 decoration: const InputDecoration(
//                   labelText: "Password",
//                   border: OutlineInputBorder(),
//                 ),
//               ),
//               const SizedBox(height: 20),
//               isLoading
//                   ? const CircularProgressIndicator()
//                   : ElevatedButton(
//                 onPressed: login,
//                 style: ElevatedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(
//                       horizontal: 40, vertical: 14),
//                   backgroundColor: Colors.blue,
//                 ),
//                 child: const Text("Login"),
//               ),
//               const SizedBox(height: 20),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 // children: [
//                 //   const Text("Don't have an account?"),
//                 //   TextButton(
//                 //     onPressed: () {
//                 //       // Navigate to SignUp page if available
//                 //       // Navigator.push(context,
//                 //       //   MaterialPageRoute(builder: (context) => const SignUpPage()));
//                 //     },
//                 //     child: const Text("Sign up"),
//                 //   ),
//                 // ],
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }


import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'homepage.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isLoading = false;

  Future<void> login() async {
    final prefs = await SharedPreferences.getInstance();
    String? baseUrl = prefs.getString("url");

    if (baseUrl == null || baseUrl.isEmpty) {
      Fluttertoast.showToast(msg: "Server URL not set");
      return;
    }

    final String username = usernameController.text.trim();
    final String password = passwordController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      Fluttertoast.showToast(msg: "Enter username and password");
      return;
    }

    // ✅ Always ensure slash
    final String apiUrl = baseUrl.endsWith("/")
        ? "${baseUrl}staff_login"
        : "$baseUrl/staff_login";

    try {
      setState(() => isLoading = true);

      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: {
          // 🔴 CHANGE THESE IF YOUR BACKEND USES DIFFERENT NAMES
          'username': username,
          'password': password,
        },
      );

      print("STATUS CODE: ${response.statusCode}");
      print("RESPONSE BODY: ${response.body}");

      if (response.statusCode != 200) {
        Fluttertoast.showToast(msg: "Server error");
        return;
      }

      final Map<String, dynamic> data = json.decode(response.body);
      print("DECODED JSON: $data");

      // ✅ HANDLE MULTIPLE BACKEND RESPONSE STYLES
      final bool isValid =
          data['task'] == 'valid' ||
              data['status'] == 'ok' ||
              data['result'] == 'success';

      if (isValid) {
        final String userType =
            data['type'] ??
                data['role'] ??
                "Staff";

        final String loginId =
            data['lid']?.toString() ??
                data['id']?.toString() ??
                data['login_id']?.toString() ??
                "";

        await prefs.setString("type", userType);
        await prefs.setString("lid", loginId);

        Fluttertoast.showToast(msg: "Login successful");

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const UserHome()),
        );
      } else {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("Login Failed"),
            content: Text(data.toString()), // 🔥 shows backend response
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("OK"),
              )
            ],
          ),
        );
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "Error: $e");
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Login")),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              TextField(
                controller: usernameController,
                decoration: const InputDecoration(
                  labelText: "Username",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 15),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: "Password",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 25),
              isLoading
                  ? const CircularProgressIndicator()
                  : SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: login,
                  child: const Text("LOGIN"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
