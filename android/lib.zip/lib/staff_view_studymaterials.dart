// import 'dart:convert';
// import 'dart:math';
//
//
//
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
//
// import 'package:shared_preferences/shared_preferences.dart';
//
//
//
//
//
// class viewstudymaterials extends StatelessWidget {
//   const viewstudymaterials({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         // This is the theme of your application.
//         //
//         // Try running your application with "flutter run". You'll see the
//         // application has a blue toolbar. Then, without quitting the app, try
//         // changing the primarySwatch below to Colors.green and then invoke
//         // "hot reload" (press "r" in the console where you ran "flutter run",
//         // or simply save your changes to "hot reload" in a Flutter IDE).
//         // Notice that the counter didn't reset back to zero; the application
//         // is not restarted.
//         primarySwatch: Colors.red,
//       ),
//       home: const viewstudymaterialspagePage(title: 'Flutter Demo Home Page'),
//       routes: {
//
//       },
//     );
//   }
// }
//
// class viewstudymaterialspagePage extends StatefulWidget {
//   const viewstudymaterialspagePage({super.key, required this.title});
//
//   // This widget is the home page of your application. It is stateful, meaning
//   // that it has a State object (defined below) that contains fields that affect
//   // how it looks.
//
//   // This class is the configuration for the state. It holds the values (in this
//   // case the title) provided by the parent (in this case the App widget) and
//   // used by the build method of the State. Fields in a Widget subclass are
//   // always marked "final".
//
//   final String title;
//
//   @override
//   State<viewstudymaterialspagePage> createState() => _viewstudymaterialspagePage();
// }
//
// class _viewstudymaterialspagePage extends State<viewstudymaterialspagePage> {
//   int _counter = 0;
//
//   _viewstudymaterialspagePage() {
//     view_college();
//   }
//
//
//
//   List<String> cid_ = <String>[];
//   List<String> csubjecttostaff_ = <String>[];
//   List<String> cstudymaterial_ = <String>[];
//   List<String> ctitle_= <String>[];
//   List<String> cdate_ = <String>[];
//
//
//   Future<void> view_college() async {
//     List<String> cid = <String>[];
//     List<String> csubjecttostaff = <String>[];
//     List<String> cstudymaterial = <String>[];
//     List<String> ctitle = <String>[];
//     List<String> cdate = <String>[];
//
//     try {
//       final pref=await SharedPreferences.getInstance();
//       String ip= pref.getString("url").toString();
//       // String lid= pref.getString("lid").toString();
//
//       String url=ip+"staff_view_studymaterials";
//       print(url);
//       print("=========================");
//
//       var data = await http.post(Uri.parse(url), body: {
//       });
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//
//       var arr = jsondata["data"];
//
//       print(arr);
//
//       print(arr.length);
//
//       for (int i = 0; i < arr.length; i++) {
//         print("okkkkkkkkkkkkkkkkkkkkkkkk");
//         cid.add(arr[i]['id'].toString());
//         csubjecttostaff.add(arr[i]['csubjecttostaff'].toString());
//         cstudymaterial.add(arr[i]['cstudymaterial'].toString());
//         ctitle.add(arr[i]['ctitle'].toString());
//         cdate.add(arr[i]['cdate'].toString());
//         print("ppppppppppppppppppp");
//       }
//
//       setState(() {
//         cid_ = cid;
//         csubjecttostaff_ = csubjecttostaff;
//         cstudymaterial_ = cstudymaterial;
//         ctitle_ = ctitle;
//         cdate_ = cdate;
//
//       });
//
//       print(cid_.length);
//       print("+++++++++++++++++++++");
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//       //there is error during converting file image to base64 encoding.
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//         appBar: AppBar(
//             title: new Text(
//               "View STUDYMATERIALS",
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.pop(context);
//                 // Navigator.pushNamed(context, '/home');
//                 // Navigator.push(context, MaterialPageRoute(builder: (context) => const  MyHomePage(title: '',)),);
//                 print("Hello");
//                 // Navigator.push(
//                 //   context,
//                 //   MaterialPageRoute(builder: (context) => ThirdScreen()),
//                 // );
//               },
//             )
//         ),
//
//         body:
//
//
//
//
//         ListView.builder(
//           physics: BouncingScrollPhysics(),
//           // padding: EdgeInsets.all(5.0),
//           // shrinkWrap: true,
//           itemCount: cid_.length,
//           itemBuilder: (BuildContext context, int index) {
//             return ListTile(
//               onLongPress: () {
//                 print("long press" + index.toString());
//               },
//               title: Padding(
//                   padding: const EdgeInsets.all(4.0),
//                   child: Column(
//                     children: [
//
//
//                       Container(
//                         width: MediaQuery. of(context). size. width,
//                         height: 500,
//                         child: Card(
//                           clipBehavior: Clip.antiAliasWithSaveLayer,
//                           child: Column(
//                             children: [
//
//
//
//
//
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("SUBJECT TO STAFF")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(csubjecttostaff_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("STUDY MATERIAL")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(cstudymaterial_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("TITLE")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(ctitle_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 9,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("DATE")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(cdate_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ), SizedBox(height: 9,),
//
//                               SizedBox(height: 9,),
//
//                               Container(
//                                 padding: EdgeInsets.all(5.0),
//                                 child:   Row(
//
//                                   children: [
//
//
//                                     // SizedBox(width: 10.0,),
//                                     // ElevatedButton(
//                                     //   onPressed: () async {
//                                     //
//                                     //     SharedPreferences prefs = await SharedPreferences.getInstance();
//                                     //     prefs.setString('bid', cid_[index]);
//                                     //
//                                     //
//                                     //     //
//                                         // Navigator.push(
//                                         //   context,
//                                         //
//                                         //   MaterialPageRoute(builder: (context) => viewROUTEUSER()),
//                                         // );
//
//                                       // },
//                                       // child: Text('view bus route'),
//                                     // ),
//
//                                   ],
//                                 ),
//                               )
//
//
//                               // Column(
//                               //     mainAxisAlignment: MainAxisAlignment.start,
//                               //     crossAxisAlignment: CrossAxisAlignment.start,
//                               //     children:[
//                               //   Text('Title'),
//                               //   Text('Subtitle')
//                               // ])
//                             ],
//                           ),
//                           shape: RoundedRectangleBorder(
//                             borderRadius: BorderRadius.circular(10.0),
//                           ),
//                           elevation: 5,
//                           margin: EdgeInsets.all(10),
//                         ),
//                       ),
//
//
//                     ],
//                   )),
//             );
//           },
//
//         )
//
//
//       // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
//
//
//
//
//
//
// }
//
//
//
//
//




import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:open_file_plus/open_file_plus.dart';
import 'package:path_provider/path_provider.dart'; // ✅ REQUIRED
import 'package:shared_preferences/shared_preferences.dart';

import 'staff_add_studymaterials.dart';

class StaffViewMaterials extends StatefulWidget {
  const StaffViewMaterials({super.key});

  @override
  State<StaffViewMaterials> createState() => _StaffViewMaterialsState();
}

class _StaffViewMaterialsState extends State<StaffViewMaterials> {
  bool isLoading = true;
  List materials = [];

  @override
  void initState() {
    super.initState();
    fetchMaterials();
  }

  Future<void> fetchMaterials() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      String url = prefs.getString('url') ?? '';
      String lid = prefs.getString('lid') ?? '';
      String sid = prefs.getString('sid') ?? '';

      if (sid.isEmpty || url.isEmpty) {
        throw Exception("Missing subject or server URL");
      }

      if (!url.endsWith('/')) url += '/';

      final response = await http.post(
        Uri.parse('${url}staff_view_studymaterials/'),
        body: {'lid': lid, 'sid': sid},
      );

      final jsonData = json.decode(response.body);

      if (jsonData['status'] == 'ok') {
        setState(() {
          materials = jsonData['data'];
          isLoading = false;
        });
      } else {
        throw Exception(jsonData['message'] ?? 'Server error');
      }
    } catch (e) {
      setState(() => isLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed: $e')),
      );
    }
  }

  Future<void> downloadAndOpenFile(String fileUrl) async {
    if (fileUrl.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('File not available')),
      );
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    String baseUrl = prefs.getString('url') ?? '';

    if (!fileUrl.startsWith('http')) {
      if (!baseUrl.endsWith('/')) baseUrl += '/';
      fileUrl = baseUrl + fileUrl;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    try {
      final response = await http.get(Uri.parse(fileUrl));

      final dir = await getApplicationDocumentsDirectory();
      final fileName = fileUrl.split('/').last;
      final file = File('${dir.path}/$fileName');

      await file.writeAsBytes(response.bodyBytes);

      if (mounted) Navigator.pop(context);

      await OpenFile.open(file.path);
    } catch (e) {
      if (mounted) Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Unable to open file')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Study Materials"),
        backgroundColor: Colors.blueGrey,
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blueGrey,
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const AddStudyMaterialPage(),
            ),
          ).then((_) {
            setState(() => isLoading = true);
            fetchMaterials();
          });
        },
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : materials.isEmpty
          ? const Center(child: Text("No study materials found"))
          : ListView.builder(
        itemCount: materials.length,
        itemBuilder: (context, index) {
          final item = materials[index];
          final fileUrl = item['file'] ?? '';

          return Card(
            margin: const EdgeInsets.all(10),
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item['title'] ?? '',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 4),
                  // Text("Subject: ${item['subject']}"),
                  Text("Date: ${item['date']}"),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: ElevatedButton.icon(
                      onPressed: () =>
                          downloadAndOpenFile(fileUrl),
                      icon: const Icon(Icons.open_in_new),
                      label: const Text("Open"),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
