import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(myapp());
}


class myapp extends StatelessWidget {
  const myapp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: samplepage(),
    );
  }
}


class samplepage extends StatefulWidget {
  const samplepage({super.key});

  @override
  State<samplepage> createState() => _samplepageState();
}

class _samplepageState extends State<samplepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(title: Text("Welcome"),backgroundColor: Colors.pink,),

      body: Column(
        children: [
          Text("hhhhhhhhhhhhhh"),


          TextFormField(decoration: InputDecoration(border: OutlineInputBorder(),label: Text("Enter Username")),),


          ElevatedButton(onPressed: (){}, child: Text("Submit"))

        ],
      ),


    );
  }
}
