import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:file_picker/file_picker.dart';

class AddStudyMaterialPage extends StatefulWidget {
  const AddStudyMaterialPage({super.key});

  @override
  State<AddStudyMaterialPage> createState() => _AddStudyMaterialPageState();
}

class _AddStudyMaterialPageState extends State<AddStudyMaterialPage> {
  final TextEditingController titleController = TextEditingController();
  File? selectedFile;
  bool isLoading = false;

  /// ---------------- PICK FILE ----------------
  Future<void> pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
    );

    if (result != null && result.files.single.path != null) {
      setState(() {
        selectedFile = File(result.files.single.path!);
      });
    }
  }

  /// ---------------- SUBMIT ----------------
  Future<void> submitStudyMaterial() async {
    if (titleController.text.isEmpty || selectedFile == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    SharedPreferences sh = await SharedPreferences.getInstance();
    String url = sh.getString('url') ?? '';
    String sid = sh.getString('sid').toString(); // subject ID from SharedPreferences
    if (!url.endsWith('/')) url += '/';

    try {
      setState(() => isLoading = true);

      var request = http.MultipartRequest(
        'POST',
        Uri.parse('${url}staff_add_studymaterials/'),
      );

      // Fields
      request.fields['sid'] = sid; // must be Assign_table.id
      request.fields['title'] = titleController.text;
      request.fields['date'] =
          DateTime.now().toString().substring(0, 10); // YYYY-MM-DD

      // File
      request.files.add(
        await http.MultipartFile.fromPath(
          'study_material', // must match Django: request.FILES.get('studymaterial')
          selectedFile!.path,
        ),
      );

      var response = await request.send();
      var responseData = await response.stream.bytesToString();
      var jsondata = json.decode(responseData);

      if (jsondata['status'] == 'ok') {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Study material added successfully")),
        );
        titleController.clear();
        setState(() => selectedFile = null);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(jsondata['message'] ?? "Error")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  /// ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add Study Material"),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: titleController,
              decoration: const InputDecoration(
                labelText: "Study Material Title",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                ElevatedButton.icon(
                  onPressed: pickFile,
                  icon: const Icon(Icons.attach_file),
                  label: const Text("Choose File"),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    selectedFile != null
                        ? selectedFile!.path.split('/').last
                        : "No file selected",
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),
            isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
              onPressed: submitStudyMaterial,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(
                    horizontal: 40, vertical: 14),
              ),
              child: const Text("Submit"),
            ),
          ],
        ),
      ),
    );
  }

}
