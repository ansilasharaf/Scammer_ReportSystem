// import 'dart:convert';
// import 'dart:math';
//
//
//
// import 'package:http/http.dart' as http;
// import 'package:flutter/material.dart';
//
// import 'package:shared_preferences/shared_preferences.dart';
//
//
//
//
//
// class view_assigned_subjects extends StatelessWidget {
//   const view_assigned_subjects({super.key});
//
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         // This is the theme of your application.
//         //
//         // Try running your application with "flutter run". You'll see the
//         // application has a blue toolbar. Then, without quitting the app, try
//         // changing the primarySwatch below to Colors.green and then invoke
//         // "hot reload" (press "r" in the console where you ran "flutter run",
//         // or simply save your changes to "hot reload" in a Flutter IDE).
//         // Notice that the counter didn't reset back to zero; the application
//         // is not restarted.
//         primarySwatch: Colors.red,
//       ),
//       home: const view_assigned_subjectspagePage(title: 'Flutter Demo Home Page'),
//       routes: {
//
//       },
//     );
//   }
// }
//
// class view_assigned_subjectspagePage extends StatefulWidget {
//   const view_assigned_subjectspagePage({super.key, required this.title});
//
//   // This widget is the home page of your application. It is stateful, meaning
//   // that it has a State object (defined below) that contains fields that affect
//   // how it looks.
//
//   // This class is the configuration for the state. It holds the values (in this
//   // case the title) provided by the parent (in this case the App widget) and
//   // used by the build method of the State. Fields in a Widget subclass are
//   // always marked "final".
//
//   final String title;
//
//   @override
//   State<view_assigned_subjectspagePage> createState() => _view_assigned_subjectspagePage();
// }
//
// class _view_assigned_subjectspagePage extends State<view_assigned_subjectspagePage> {
//   int _counter = 0;
//
//   _view_assigned_subjectspagePage() {
//     view_college();
//   }
//
//
//
//   List<String> cid_ = <String>[];
//   List<String> csubject_name_ = <String>[];
//   List<String> csubject_code_ = <String>[];
//   List<String> csemester_= <String>[];
//   List<String> cdate_ = <String>[];
//   List<String> cstatus_ = <String>[];
//
//   Future<void> view_college() async {
//     List<String> cid = <String>[];
//     List<String> csubject_name = <String>[];
//     List<String> csubject_code = <String>[];
//     List<String> csemester = <String>[];
//     List<String> cdate = <String>[];
//     List<String> cstatus = <String>[];
//
//     try {
//       final pref=await SharedPreferences.getInstance();
//       String ip= pref.getString("url").toString();
//       // String lid= pref.getString("lid").toString();
//
//       String url=ip+"staff_view_assignedsubject";
//       print(url);
//       print("=========================");
//
//       var data = await http.post(Uri.parse(url), body: {
//       });
//       var jsondata = json.decode(data.body);
//       String status = jsondata['status'];
//
//       var arr = jsondata["data"];
//
//       print(arr);
//
//       print(arr.length);
//
//       for (int i = 0; i < arr.length; i++) {
//         print("okkkkkkkkkkkkkkkkkkkkkkkk");
//         cid.add(arr[i]['id'].toString());
//         csubject_name.add(arr[i]['csubject_name'].toString());
//         csubject_code.add(arr[i]['csubject_code'].toString());
//         csemester.add(arr[i]['csemester'].toString());
//         cdate.add(arr[i]['cdate'].toString());
//         cstatus.add(arr[i]['cstatus'].toString());
//         print("ppppppppppppppppppp");
//       }
//
//       setState(() {
//         cid_ = cid;
//         csubject_name_ = csubject_name;
//         csubject_code_ = csubject_code;
//         csemester_ = csemester;
//         cdate_ = cdate;
//         cstatus_ = cstatus;
//
//       });
//
//       print(cid_.length);
//       print("+++++++++++++++++++++");
//       print(status);
//     } catch (e) {
//       print("Error ------------------- " + e.toString());
//       //there is error during converting file image to base64 encoding.
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     // This method is rerun every time setState is called, for instance as done
//     // by the _incrementCounter method above.
//     //
//     // The Flutter framework has been optimized to make rerunning build methods
//     // fast, so that you can just rebuild anything that needs updating rather
//     // than having to individually change instances of widgets.
//     return Scaffold(
//         appBar: AppBar(
//             title: new Text(
//               "View STUDYMATERIALS",
//               style: new TextStyle(color: Colors.white),
//             ),
//             leading: new IconButton(
//               icon: new Icon(Icons.arrow_back),
//               onPressed: () {
//                 Navigator.pop(context);
//                 // Navigator.pushNamed(context, '/home');
//                 // Navigator.push(context, MaterialPageRoute(builder: (context) => const  MyHomePage(title: '',)),);
//                 print("Hello");
//                 // Navigator.push(
//                 //   context,
//                 //   MaterialPageRoute(builder: (context) => ThirdScreen()),
//                 // );
//               },
//             )
//         ),
//
//         body:
//
//
//
//
//         ListView.builder(
//           physics: BouncingScrollPhysics(),
//           // padding: EdgeInsets.all(5.0),
//           // shrinkWrap: true,
//           itemCount: cid_.length,
//           itemBuilder: (BuildContext context, int index) {
//             return ListTile(
//               onLongPress: () {
//                 print("long press" + index.toString());
//               },
//               title: Padding(
//                   padding: const EdgeInsets.all(4.0),
//                   child: Column(
//                     children: [
//
//
//                       Container(
//                         width: MediaQuery. of(context). size. width,
//                         height: 500,
//                         child: Card(
//                           clipBehavior: Clip.antiAliasWithSaveLayer,
//                           child: Column(
//                             children: [
//
//
//
//
//
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("SUBJECT NAME")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(csubject_name_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("SUBJECT CODE")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(csubject_code_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//
//
//                               SizedBox(height: 16,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("SEMESTER")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(csemester_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ),
//                               SizedBox(height: 9,),
//                               Row(
//
//                                 children: [
//                                   SizedBox(
//                                     width: 10,
//                                   ),
//
//                                   Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("DATE")])),
//                                   Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(cdate_[index])])),
//
//                                   // Text("Place"),
//                                   // Text(place_[index])
//                                 ],
//                               ), SizedBox(height: 9,),
//
//                           Row(
//
//                             children: [
//                               SizedBox(
//                                 width: 10,
//                               ),
//
//                               Flexible(flex: 2, fit: FlexFit.loose, child: Row(children: [Text("STATUS")])),
//                               Flexible(flex: 3, fit: FlexFit.loose, child: Row(children: [Text(cstatus_[index])])),
//
//                               // Text("Place"),
//                               // Text(place_[index])
//
//
//                               SizedBox(height: 9,),
//
//                               Container(
//                                 padding: EdgeInsets.all(5.0),
//                                 child:   Row(
//
//                                   children: [
//
//
//                                     // SizedBox(width: 10.0,),
//                                     // ElevatedButton(
//                                     //   onPressed: () async {
//                                     //
//                                     //     SharedPreferences prefs = await SharedPreferences.getInstance();
//                                     //     prefs.setString('bid', cid_[index]);
//                                     //
//                                     //
//                                     //     //
//                                     // Navigator.push(
//                                     //   context,
//                                     //
//                                     //   MaterialPageRoute(builder: (context) => viewROUTEUSER()),
//                                     // );
//
//                                     // },
//                                     // child: Text('view bus route'),
//                                     // ),
//
//                                   ],
//                                 ),
//                               )
//
//
//                               // Column(
//                               //     mainAxisAlignment: MainAxisAlignment.start,
//                               //     crossAxisAlignment: CrossAxisAlignment.start,
//                               //     children:[
//                               //   Text('Title'),
//                               //   Text('Subtitle')
//                               // ])
//                             ],
//                           ),
//
//                         ]
//                         ),
//                       ),
//
//
//
//                   ),
//          ]   )
//
//             )
//             );
//           },
//
//         )
//
//
//       // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
//
//
//
//
//
//
// }
//
//
//
//
//



import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:scammerreport/staff_add_studymaterials.dart';
import 'package:scammerreport/staff_view_studymaterials.dart';
 // <-- study material page
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const ViewSub());
}

class ViewSub extends StatelessWidget {
  const ViewSub({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ViewSubPage(title: 'Subjects'),
    );
  }
}

class ViewSubPage extends StatefulWidget {
  const ViewSubPage({super.key, required this.title});
  final String title;

  @override
  State<ViewSubPage> createState() => _ViewSubPageState();
}

class _ViewSubPageState extends State<ViewSubPage> {
  List<String> id_ = [];
  List<String> subjectName_ = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchSubjects();
  }

  Future<void> fetchSubjects() async {
    try {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String url = sh.getString('url') ?? '';
      String lid = sh.getString('lid') ?? '';
      if (!url.endsWith('/')) url += '/';

      final response = await http.post(
        Uri.parse('${url}staff_view_subject/'),
        body: {'lid': lid},
      );

      final jsondata = json.decode(response.body);

      if (jsondata['status'] == 'ok') {
        List temp = jsondata['data'];

        setState(() {
          id_ = temp.map<String>((e) => e['id'].toString()).toList();
          subjectName_ =
              temp.map<String>((e) => e['subject'].toString()).toList();
          isLoading = false;
        });
      } else {
        isLoading = false;
      }
    } catch (e) {
      isLoading = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    double sw = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        centerTitle: true,
        backgroundColor: Colors.blueGrey,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : subjectName_.isEmpty
          ? const Center(child: Text("No subjects found"))
          : ListView.builder(
        itemCount: subjectName_.length,
        itemBuilder: (context, index) {
          return Container(
            width: sw * 0.9,
            margin: const EdgeInsets.symmetric(
                vertical: 8, horizontal: 12),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /// SUBJECT NAME
                    Row(
                      children: [
                        const Icon(Icons.book,
                            color: Colors.blueGrey),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            subjectName_[index],
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 14),

                    /// ACTION BUTTONS
                    Row(
                      mainAxisAlignment:
                      MainAxisAlignment.spaceBetween,
                      children: [
                        /// ATTENDANCE BUTTON

                        // / STUDY MATERIAL BUTTON
                        ElevatedButton.icon(
                          icon: const Icon(Icons.menu_book),
                          label: const Text("Materials"),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                            Colors.green,
                          ),
                          onPressed: () async {
                            SharedPreferences sh =
                            await SharedPreferences
                                .getInstance();
                            sh.setString('sid', id_[index]);

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                const StaffViewMaterials(),
                              ),
                            );
                          },
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

