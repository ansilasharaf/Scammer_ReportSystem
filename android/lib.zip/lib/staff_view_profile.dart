import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

class viewprofile extends StatefulWidget {
  const viewprofile({super.key});

  @override
  State<viewprofile> createState() => _viewprofileState();
}

class _viewprofileState extends State<viewprofile> {
  bool _isAvailable = true; // Track availability status
  String _teamName = "Rescue Team Alpha"; // Sample data, replace with actual data fetching
  String numberOfMembers = "2"; // Sample data
  String contactOne = "1234567890"; // Sample contact number
  String contactTwo = "9876543210"; // Sample contact number
  String officerName = ""; // Sample officer name
  String status="";

  @override
  void initState() {
    super.initState();
    viewProfile();
    // updateAvailability();
  }
  bool stringToBool(String value) {
    if (value.toLowerCase() == 'true') {
      return true;
    } else if (value.toLowerCase() == 'false') {
      return false;
    } else {
      throw FormatException("Invalid boolean string: '$value'");
    }
  }
  Future<void> viewProfile() async {
    print("view_profile===");
    try {
      final pref = await SharedPreferences.getInstance();
      String ip = pref.getString("url").toString();
      String lid = pref.getString("lid").toString();

      String url = ip + "em_view_profile";
      print(url);
      print("=========================");

      var data = await http.post(Uri.parse(url), body: {'lid': lid});
      var jsondata = json.decode(data.body);
      print(jsondata); // Print the API response for debugging

      // Access profile fields directly from jsondata
      if (jsondata != null) {
        setState(() {
          _teamName = jsondata['name'].toString();
          contactOne = jsondata['con1'].toString();
          contactTwo = jsondata['con2'].toString();
          numberOfMembers = jsondata['address'].toString();
          _isAvailable= stringToBool(jsondata['availability']);
          // photo = ip + jsondata['photo'].toString(); // Update image URL

        });
        // setState((){});
      } else {
        print("No profile data found in the response");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  // Function to update the availability
  Future<void> updateAvailability() async {
    // setState(() {
    //   // Toggle the availability status
    //   _isAvailable = !_isAvailable;
    //
    // });

    // Save the availability status to the serve
    // r or database here

    if (_isAvailable){
      status="false";
      setState(() {
        // Toggle the availability status
        _isAvailable = false;

      });
    }
    else{
      status="true";
      setState(() {
        // Toggle the availability status
        _isAvailable = true;

      });
    }

    final sh = await SharedPreferences.getInstance();
    String url = sh.getString("url").toString();
    print(url);
    try {
      print("started");
      var data = await http.post(
        Uri.parse(url + "update_availablity"),
        body: {
          'lid': sh.getString("lid"),
          "st":status,
        },
      );
      var jasondata = jsonDecode(data.body);
      String sts = jasondata['status'].toString();

      if (sts == "ok") {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Welcome"),
            duration: Duration(seconds: 4),
          ),

        );


      }


      else {
        // Show an error message for invalid username or password
        showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text('updation Failed'),
              content: Text(
                  'Please try again.'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('OK'),
                ),
              ],
            );
          },
        );
      }
    }
    catch(e)
    {
      print(e);
      Fluttertoast.showToast(msg: "oooooooooooooo"+e.toString());
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Availability updated to ${_isAvailable ? "on" : "off"}'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Rescue Team Profile'),
        backgroundColor: Colors.greenAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Team Details Section
            Row(
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundImage: AssetImage(
                      'assets/rescue_team.jpg'), // Placeholder image, replace with actual team image
                ),
                SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _teamName,
                      style: TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'Officer: $officerName',
                      style:
                      TextStyle(fontSize: 16, color: Colors.grey[600]),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 24),
            // Availability Section
            Text(
              'Update Availability',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 16),
            Row(
              children: [
                Text(
                  'Available',
                  style: TextStyle(fontSize: 16),
                ),
                Spacer(),
                Switch(
                  value: _isAvailable,
                  onChanged: (value) {
                    updateAvailability();
                  },
                ),
              ],
            ),
            SizedBox(height: 16),
            // Rescue Team Information
            buildInfoRow('Number of Members', numberOfMembers.toString()),
            buildInfoRow('Primary Contact', contactOne.toString()),
            buildInfoRow('Secondary Contact', contactTwo.toString()),
            SizedBox(height: 24),
            // Update Button
            Center(
              // child: ElevatedButton(
              //   onPressed: updateAvailability,
              //   child: Text('Update'),
              //   style: ElevatedButton.styleFrom(
              //     primary: Colors.greenAccent,
              //     padding:
              //     EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              //     textStyle: TextStyle(
              //         fontSize: 16, fontWeight: FontWeight.bold),
              //   ),
              // ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build information rows
  Widget buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16, color: Colors.black54),
          ),
          Text(
            value,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
